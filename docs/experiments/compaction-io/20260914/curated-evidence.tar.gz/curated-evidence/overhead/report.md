# R3-v4 P5 instrumentation overhead

Run order: M0-r1, M1-r1, M1-r2, M0-r2, M0-r3, M1-r3

Pair formulas: signed delta=(M1-M0)/M0; degradation=(M0-M1)/M0.

Mean degradation: -0.0840584738
M0 throughput mean ops/s: 14576.575
M0 throughput sample SD ops/s: 810.40766
M1 throughput mean ops/s: 15765.2506
M1 throughput sample SD ops/s: 176.250272
Pairs over 5% degradation: 0
Frozen gate: PASS (mean degradation <= 3%; fewer than 2 pairs > 5%).

Supporting context (measurement-window samples, per run):
M0-r1: compaction_worker_us_s=NA
M1-r1: CPU user=0.91498642 system=1.08181847 iowait=36.3458247 idle=59.6299168; device read=0.0001137136 MB/s write=0.0986647053 MB/s await=0.0354912263/2.21921959 ms queue=0.00416377516 util=1.14464932%; compaction_worker_us_s=997895.546
M1-r2: CPU user=0.933389847 system=1.10705498 iowait=36.5435866 idle=59.3952416; device read=0.00797641087 MB/s write=0.095696239 MB/s await=0.0177877834/2.17561761 ms queue=0.0367800139 util=1.16200375%; compaction_worker_us_s=997735.578
M0-r2: compaction_worker_us_s=NA
M0-r3: compaction_worker_us_s=NA
M1-r3: CPU user=0.9519254 system=1.11132733 iowait=36.7463438 idle=59.151337; device read=0.0114023725 MB/s write=0.107422438 MB/s await=0.0401067069/1.96373142 ms queue=0.00555170021 util=1.17821337%; compaction_worker_us_s=997733.031
Device identity is captured in each run's diskstats.raw and iostat.raw evidence.

READ and UPDATE remain separate. Operation P99: NA; NOT_APPLICABLE because W1 has no reads and existing P99 is not exact-window-valid.
