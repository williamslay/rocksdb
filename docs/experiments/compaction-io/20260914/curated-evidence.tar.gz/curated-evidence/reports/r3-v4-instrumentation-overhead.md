# R3-v4 Frozen Paired Overhead Gate

The stale classification wording is superseded by the actual frozen paired
V4 gate result below.

Pair formula: `(M0 - M1) / M0`.

| Pair | M0 ops/s | M1 ops/s | Degradation | Valid P99 regression |
|---|---:|---:|---:|---:|
| r1 | 14832.5158 | 15906.5542 | -7.24110694% | NA |
| r2 | 15228.1117 | 15567.7558 | -2.23037612% | NA |
| r3 | 13669.0975 | 15821.4417 | -15.7460591% | NA |

Mean degradation: `-8.40584738%`.
Pairs over 5% degradation: `0`.
Exact-window-valid operation P99 was unavailable for this W1 overhead matrix;
raw P99 values are retained in `overhead/per-run.csv` as non-gating context.

OVERHEAD_GATE_PASS
