# R3-v4 Final Acceptance Report

PROTOCOL_CLEAN = PASS
BUILD_CUSTODY = PASS
SEED_CUSTODY = PASS
OVERHEAD_GATE = PASS
FORMAL_RUN_VALIDITY = PASS
FORMAL_INDEPENDENT_REPLAY = PASS
Q1_EVIDENCE = PASS
Q2_EVIDENCE = PASS
Q3_EVIDENCE = PASS

R3_V4_FORMAL_RESULT_ACCEPTED

This report uses only custody-complete R3-v4 runs in this result generation.
No workload was rerun during report acceptance. Six overhead runs and nine
formal runs are included. Earlier invalid attempts remain excluded evidence.

## Acceptance Basis

- Protocol version: `R3-v4`.
- Formal matrix: W1, A, and B; three runs each; 1200-second measurement windows.
- Threads: 32. Target: 0. Warmup: 180 seconds. Guard: 60 seconds.
- Canonical seed manifest SHA-256:
  `3612576799ea9c6b69889d90d059ca1bc7b3b4fd16d9398c5faa993c2bb736dd`.
- Frozen native SHA-256:
  `b5c8db3a9d7011cdc39867fac9ca35f948ad629cd9f8bfe084abb15ee252ab71`.
- JNI SHA-256:
  `0f58efab71e733d3d4a7ef0057becab8a873d31b3a884a79f20438334867fc17`.
- Adapter SHA-256:
  `c68c8f7148a6b694113cbc1d7be9074e8a55bf1a24c2c358186e030d5dc554d9`.
- Protocol SHA-256:
  `577ef83a9c6b58643791d1b442b99a98d20f6c158fedf6b9770a7971a19ebaae`.
- Readiness controls: `PROTOCOL_CLEAN`, D2 source semantics, schema validation,
  missing-field fixture, and async consumer-wait positive control all PASS.

## Overhead

Frozen pair formula:

`throughput_degradation = (M0 - M1) / M0`

Gate: mean degradation <= 3% and fewer than two of three pairs over 5%.
Only exact-window-valid operation P99 values are eligible. No exact-window-valid
P99 was available for this W1 overhead matrix; P99 values are therefore shown
as `NA` and are not fabricated or used as valid regressions.

| Pair | M0 ops/s | M1 ops/s | Degradation | Valid READ P99 regression | Valid UPDATE P99 regression |
|---|---:|---:|---:|---:|---:|
| r1 | 14832.5158 | 15906.5542 | -7.24110694% | NA | NA |
| r2 | 15228.1117 | 15567.7558 | -2.23037612% | NA | NA |
| r3 | 13669.0975 | 15821.4417 | -15.7460591% | NA | NA |

Mean throughput degradation: `-8.40584738%`.
Pairs over 5% degradation: `0`.
Raw UPDATE P99 values were 11247 -> 9623 us, 11151 -> 10383 us, and
13911 -> 9895 us, but these are non-gating because exact-window validity was
not established.

OVERHEAD_GATE_PASS

## Q1: Critical-Path Ordering

Run-level ratios use aggregate compaction worker-time as denominator.

| Workload | Run | E_read | E_write | E_sync | Check |
|---|---|---:|---:|---:|---|
| W1 | w1-r1 | 0 | 0.122684140 | 0.019625095 | PASS |
| W1 | w1-r2 | 0 | 0.143185849 | 0.024216918 | PASS |
| W1 | w1-r3 | 0 | 0.133141909 | 0.020793443 | PASS |
| A | a-r1 | 0 | 0.118830171 | 0.019937676 | PASS |
| A | a-r2 | 0 | 0.103968185 | 0.020080759 | PASS |
| A | a-r3 | 0 | 0.102101253 | 0.020104562 | PASS |
| B | b-r1 | 0 | 0.106520290 | 0.020209132 | PASS |
| B | b-r2 | 0 | 0.100293432 | 0.021085331 | PASS |
| B | b-r3 | 0 | 0.106307396 | 0.022545319 | PASS |

Every run satisfies `E_write > E_sync` and `E_write > E_read`.

CONTINUOUS_DATA_WRITE_DOMINANT

## Q2: Storage-Pressure Exposure

Analysis uses retained time-aligned formal evidence only. Intervals were
eligible when `delta_compaction_worker_us > 0`. For each eligible interval:

`normalized_write_exposure = delta_write_blocked_us / delta_compaction_worker_us`

Bottom and top groups are the bottom and top quintiles by normalized exposure
within each workload. Compaction worker time is used as the denominator and
eligibility condition; compaction duty-cycle alone does not classify exposure.

| Workload | Active intervals | Group | N | Raw delta_write_blocked_us mean | Normalized exposure mean |
|---|---:|---|---:|---:|---:|
| W1 | 3575 | bottom quintile | 715 | 60909.445 | 0.064529 |
| W1 | 3575 | top quintile | 715 | 360067.357 | 0.366532 |
| A | 2665 | bottom quintile | 533 | 55672.897 | 0.062962 |
| A | 2665 | top quintile | 533 | 244348.403 | 0.262713 |
| B | 528 | bottom quintile | 105 | 57045.333 | 0.065363 |
| B | 528 | top quintile | 105 | 178783.381 | 0.193638 |

Storage context is reported as mean / median / P95 for latency and mean for
the remaining metrics.

| Workload | Group | w_await ms | aqu-sz | write MB/s | util % | CPU iowait % |
|---|---|---:|---:|---:|---:|---:|
| W1 | bottom | 0.320 / 0.230 / 0.894 | 31.562 / 32 / 36 | 149.253 | 99.968 | 37.034 |
| W1 | top | 3.010 / 2.619 / 7.234 | 34.355 / 34 / 44 | 162.943 | 99.970 | 37.435 |
| A | bottom | 0.389 / 0.230 / 1.526 | 31.270 / 32 / 36 | 140.364 | 99.950 | 36.959 |
| A | top | 1.866 / 0.827 / 5.664 | 32.818 / 32 / 42 | 148.326 | 99.964 | 37.320 |
| B | bottom | 0.367 / 0.230 / 1.333 | 30.848 / 32 / 36 | 142.114 | 99.916 | 36.978 |
| B | top | 1.102 / 0.584 / 2.755 | 31.076 / 32 / 36 | 149.401 | 99.960 | 37.120 |

All workloads show higher raw write-blocked time and higher worker-normalized
write exposure in the high-exposure quintile, with higher write latency
context. This is non-causal storage-pressure evidence, not proof that storage
pressure caused the critical-path exposure.

STORAGE_CONGESTION_EXPOSURE_SUPPORTED

## Q3: Depth-2 Read Hiding Audit

Required prerequisites were checked against each formal run:

- logical compaction input bytes are positive;
- runtime effective depth is 2;
- configured compaction readahead is 1048576 bytes (1 MiB);
- loaded native SHA-256 matches the frozen validated implementation;
- read fields `E_read` and `T_read` are present in production and replay data;
- independent endpoint replay gives `T_read = 0` with exact production match;
- device read activity is positive in captured samples.

| Run | Logical input bytes | Depth | Readahead | Native match | Read fields | Replay T_read | Device read min MB/s |
|---|---:|---:|---:|---|---|---:|---:|
| w1-r1 | 201638332145 | 2 | 1048576 | PASS | PASS | 0, exact | 202.893 |
| w1-r2 | 190836864666 | 2 | 1048576 | PASS | PASS | 0, exact | 120.521 |
| w1-r3 | 197535311823 | 2 | 1048576 | PASS | PASS | 0, exact | 119.558 |
| a-r1 | 143379918294 | 2 | 1048576 | PASS | PASS | 0, exact | 110.697 |
| a-r2 | 145043284363 | 2 | 1048576 | PASS | PASS | 0, exact | 110.721 |
| a-r3 | 145348315815 | 2 | 1048576 | PASS | PASS | 0, exact | 110.071 |
| b-r1 | 33010871660 | 2 | 1048576 | PASS | PASS | 0, exact | 110.537 |
| b-r2 | 32965850734 | 2 | 1048576 | PASS | PASS | 0, exact | 3.636 |
| b-r3 | 31406684144 | 2 | 1048576 | PASS | PASS | 0, exact | 4.204 |

Read fields are explicit zero-valued measurements, not missing-field defaults:
the production aggregation and independent endpoint replay contain the fields,
and the replay matches at stored precision. Physical device read activity is
positive in every formal run. The readiness async consumer-wait positive
control, D2 source semantics audit, and missing-field validation also PASS.

Under the measured depth-2 configuration, substantial compaction input
processing occurred while no consumer-visible residual compaction input-I/O
wait was observed. This does not claim that device or NAND latency disappeared.

D2_READ_HIDING_SUPPORTED

## Final Mechanism Result

Across W1, A, and B, the exposed compaction I/O critical path is consistently
dominated by continuous output data-write/completion/backpressure rather than
final output sync.

Q2 is reported separately as non-causal storage-pressure evidence from raw and
worker-normalized time-aligned intervals.

Q3 is reported separately using validated consumer-visible wait semantics:
under depth 2, input processing and physical device reads occurred while the
validated consumer-visible `T_read` endpoint remained zero.

## Custody Matrix

Hash prefixes below refer to the full frozen identities in Acceptance Basis:
protocol `577ef83a`, native `b5c8db3a`, JNI `0f58efab`, adapter `c68c8f71`,
and canonical seed manifest `36125767`.

| Run ID | Workload | Telemetry | Protocol | Native | Loaded match | JNI | Adapter | Seed manifest | Seed copy | Runtime options | Measurement evidence | Replay | Final validity |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| M0-r1 | W1 | off | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| M1-r1 | W1 | on | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| M1-r2 | W1 | on | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| M0-r2 | W1 | off | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| M0-r3 | W1 | off | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| M1-r3 | W1 | on | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| r4c-w1-r1 | W1 | on | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| r4c-w1-r2 | W1 | on | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| r4c-w1-r3 | W1 | on | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| r4c-a-r1 | A | on | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| r4c-a-r2 | A | on | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| r4c-a-r3 | A | on | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| r4c-b-r1 | B | on | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| r4c-b-r2 | B | on | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |
| r4c-b-r3 | B | on | 577ef83a | b5c8db3a | PASS | 0f58efab | c68c8f71 | 36125767 | PASS | PASS | PASS | PASS | PASS |

## Evidence Files

- `summary/r3-v4-report.md` - this accepted report.
- `summary/r3-v4-per-run.csv` - nine run-level ratios and counters.
- `summary/r3-v4-temporal.csv` - time-aligned Q2 evidence.
- `overhead/pairwise.csv` and `overhead/report.md` - frozen overhead pairs.
- `replay/r3-v4-custody-complete-independent-replay.csv` - final nine-run
  independent endpoint replay.
