# Compaction Exposed-I/O Experiment

## Goal

Determine whether RocksDB compaction exposes input-storage latency to the merge
critical path, and whether a larger ahead-of-consumption window reduces that
stall. Do not implement CMM-H, Cylon, device caching, or unrelated tuning in
this experiment.

## Current readiness

- Repository root is on `/dev/nvme0n1p2`.
- `/dev/nvme1n1p1` exists but is not mounted.
- `fio` is not installed.
- `db_bench` built as the no-gflags stub; `--help` cannot expose benchmark flags
  and prints `Please install gflags to run rocksdb tools`.
- No large test file, raw-device write, or benchmark run has been started.
- The local compaction path is synchronous (`num_buffers=1`). A readahead sweep
  alone cannot prove independent lookahead depth or latency hiding.

## Gates

### P0: Environment

Choose an explicit filesystem directory `<TEST_ROOT>` on the target NVMe. Do
not use an unknown raw device. Capture:

```bash
mkdir -p <TEST_ROOT>/results/environment
uname -a > <TEST_ROOT>/results/environment/hardware.txt
cat /etc/os-release >> <TEST_ROOT>/results/environment/hardware.txt
lscpu >> <TEST_ROOT>/results/environment/hardware.txt
numactl --hardware >> <TEST_ROOT>/results/environment/hardware.txt
lsblk -o NAME,MODEL,SERIAL,SIZE,ROTA,TYPE,FSTYPE,MOUNTPOINTS \
  > <TEST_ROOT>/results/environment/nvme.txt
findmnt -T <TEST_ROOT> >> <TEST_ROOT>/results/environment/nvme.txt
git -C <ROCKSDB_ROOT> rev-parse HEAD \
  > <TEST_ROOT>/results/environment/rocksdb_commit.txt
git -C <ROCKSDB_ROOT> status --short \
  >> <TEST_ROOT>/results/environment/rocksdb_commit.txt
<ROCKSDB_ROOT>/db_bench --help \
  > <TEST_ROOT>/results/environment/db_bench_help.txt
fio --version >> <TEST_ROOT>/results/environment/hardware.txt
```

Install or provide `fio` and gflags, then build with the required release
command before continuing:

```bash
AUTO_CLEAN=1 DEBUG_LEVEL=0 make db_bench
```

### P1: SSD envelope

Create a 32--64 GiB regular file under `<TEST_ROOT>` only after confirming free
space and mount point. Use `direct=1`, `rw=read`, and sweep request sizes
`128k, 512k, 1m, 2m` over queue depths `1,2,4,8,16,32,64`. Capture BW, IOPS,
average latency, p50, p95, and p99. Define `B_ssd_max` from the sustained
plateau and record the queue depth reaching 90--95% of it. Never run write fio
against `/dev/nvme*`.

### P2: Local source semantics

Use `results/source-path.md`. Confirm it against the exact commit before using
any sweep result as causal evidence.

### P3: Reproducible seed

Build one fixed seed with compression disabled, approximately 1 KiB values,
automatic compaction disabled, and enough small write buffers to create
overlapping L0 files. Target at least 16 GiB of compaction input; increase it
until one `compact0` lasts several seconds. Save `levelstats`, `sstables`, the
OPTIONS file, MANIFEST state, disk usage, and the generation command.

Restore an identical seed before every run. Prefer `cp --reflink=auto`; record
whether reflink was used. Randomize run order. Use at least three repetitions
per point, preferably five.

### P4: Screening sweep

Build and verify exact flags with `db_bench --help`. The local names are
`--mmap_read=false` and `--mmap_write=false`; the handoff names
`allow_mmap_reads/writes` are option fields, not db_bench flags. Use:

```bash
db_bench \
  --db=<RUN_DB> \
  --use_existing_db=true \
  --benchmarks=compact0,stats,levelstats \
  --compaction_readahead_size=<W_BYTES> \
  --use_direct_reads=true \
  --use_direct_io_for_flush_and_compaction=true \
  --mmap_read=false \
  --mmap_write=false \
  --statistics=true \
  --report_bg_io_stats=true \
  --subcompactions=1 \
  --max_background_compactions=1
```

Sweep `W = 0, 256 KiB, 512 KiB, 1 MiB, 2, 4, 8, 16, 32, 64, 128, 256 MiB`
where alignment and local implementation permit. Record wall time, CPU time,
`COMPACT_READ_BYTES`, `COMPACT_WRITE_BYTES`,
`COMPACTION_PREFETCH_BYTES`, `FILE_READ_COMPACTION_MICROS`, and NVMe
`rMB/s,wMB/s,r_await,w_await,aqu-sz,%util` from `iostat -x 1`. `perf stat`
is optional. `FILE_READ_COMPACTION_MICROS` is auxiliary, not
`T_exposed_io`.

### P5/P6: Causal checkpoint

Inspect before modifying. Current code explicitly disallows async compaction
reads and asserts `num_buffers == 1`; therefore the screening sweep changes
the synchronous request/refill size. It does not vary `N` in
`W_effective = S * N`.

Only if P4 shows a candidate effect, add a narrowly scoped experimental
instrumentation path, test-first, that records:

- `T_io_service`: request issue to completion;
- `T_overlap`: I/O in flight while merge consumes ready data;
- `T_exposed_io`: consumer needs data, data is not ready, and progress stops;
- stall count and p50/p95/p99;
- ready bytes, prefetched bytes, consume offset, and outstanding reads.

Then hold request size `S` fixed at 1 MiB and sweep buffer depth `N = 1,2,4,8,
16,32,64`. Do not interpret a synthetic harness as end-to-end proof.

## Scenario contract

1. Happy path: identical seed, one `compact0`, direct I/O, randomized repeated
   W points. Pass only if input/output bytes and CPU work remain comparable and
   direct `T_exposed_io` falls with W and tracks lower wall time.
2. Edge path: `W=0` and smallest aligned W. Pass only if run completes without
   alignment errors and statistics show no extra prefetch at W=0.
3. Regression path: repeat one chosen W from a restored seed. Pass only if
   checksums, user data, levelstats, SST count, and input/output byte invariants
   match the baseline.

## Decision rules

- Positive only when direct `T_exposed_io` decreases, compaction wall time
  decreases, CPU work per input byte stays stable, and small-W read BW is below
  `B_ssd_max`.
- `E_io` near zero at every W means storage latency is already hidden.
- High `E_io` with read BW near `B_ssd_max` means bandwidth-bound.
- Wall-time improvement without lower `T_exposed_io` means request-size or
  syscall overhead, not lookahead proof.
- Saturated write-side telemetry invalidates the read-prefetch conclusion until
  output writes are moved to an independent device.

## Stop line

Stop when every scenario has RED/GREEN evidence where code was changed, the
real-surface artifacts are captured, the source-path and environment records
are complete, and the report answers Q1--Q6 without claiming latency hiding
from the screening sweep alone.
