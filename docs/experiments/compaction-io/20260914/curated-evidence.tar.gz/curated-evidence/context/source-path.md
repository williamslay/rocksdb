# Local Compaction Prefetch Source Path

Commit inspected: working tree at preparation time.

## Call path

`CompactionJob::CreateInputIterator`
(`db/compaction/compaction_job.cc:1529`) initializes compaction `ReadOptions`
and calls `VersionSet::MakeInputIterator`. That reaches
`TableCache::NewIterator` (`db/table_cache.cc:350`), which passes
`file_options.compaction_readahead_size` and caller `kCompaction` into the
table reader (`db/table_cache.cc:398-401`).

`BlockBasedTable::NewIterator` (`table/block_based/block_based_table_reader.cc:
2758`) constructs `BlockBasedTableIterator` with that size. During data-block
initialization (`table/block_based/block_based_table_iterator.cc:440-480`), the
iterator calls `BlockPrefetcher::PrefetchIfNeeded` with
`is_for_compaction=true` and `read_options_.async_io`.

`CompactionJob::InitializeReadOptionsAndBoundaries`
(`db/compaction/compaction_job.cc:1467-1478`) does not enable async I/O, so the
normal compaction path passes `false`.

## Effective behavior

`BlockPrefetcher::PrefetchIfNeeded`
(`table/block_based/block_prefetcher.cc:15-70`) sets
`initial_readahead_size` and `max_readahead_size` to the compaction value, and
sets `num_buffers` to 1 when async prefetch is false. For non-direct I/O and a
positive size it first tries filesystem `Prefetch()`. For direct I/O it skips
that branch and creates an internal `FilePrefetchBuffer`.

`BlockBasedTable::Rep::CreateFilePrefetchBuffer`
(`table/block_based/block_based_table_reader.h:906-915`) enables that buffer
when mmap reads are disabled and attaches RocksDB statistics.

`FilePrefetchBuffer::TryReadFromCacheUntracked`
(`file/file_prefetch_buffer.cc:803-909`) asserts `num_buffers == 1` for
compaction and calls `PrefetchInternal` synchronously. It reads the requested
block plus the configured readahead in one refill. `FilePrefetchBuffer::Prefetch`
also asserts one buffer (`file/file_prefetch_buffer.cc:179-223`).

The async multi-buffer implementation exists in
`FilePrefetchBuffer::PrefetchAsync` and `PrefetchRemBuffers`
(`file/file_prefetch_buffer.cc:941-1111`), but it is not available to this
compaction path. Async completion waits occur in `PollIfNeeded`
(`file/file_prefetch_buffer.cc:366-397`), and are therefore user/async-read
behavior, not current compaction producer-consumer overlap.

## Answers to handoff questions

1. Compaction input gets its prefetch buffer through `BlockPrefetcher`, created
   by the block-based table reader.
2. `compaction_readahead_size` controls the fixed refill extension for the
   internal buffer, or the extension passed to filesystem `Prefetch()` when
   reads are buffered.
3. In current compaction, each block-based table iterator owns one
   `BlockPrefetcher` and its buffer; the buffer has one active data buffer.
4. Current compaction refill is synchronous. Async APIs exist but are not used
   because compaction has `num_buffers=1`.
5. No double/multi-buffer compaction pipeline is active in this path.
6. Refill occurs when requested block data is absent or incomplete; the
   synchronous path reads request plus configured readahead. The async path,
   when used elsewhere, fills remaining buffers via `PrefetchRemBuffers`.
7. Current compaction consumer waits inside the synchronous `Read()`/refill
   call. It does not wait on an asynchronous completion queue.
8. Direct-I/O read length is rounded to the file alignment by
   `ReadAheadSizeTuning`; the requested block plus readahead determines the
   unaligned logical range before rounding.
9. With `compaction_readahead_size=0`, the internal buffer has zero extension;
   direct compaction reads still fetch the requested block, but no extra
   readahead is scheduled.

## Experimental consequence

The first W sweep is valid as screening for synchronous refill size, syscall
overhead, and sequential-read efficiency. It cannot establish
`T_exposed_io = consumer blocked while an outstanding read is incomplete` in
the unmodified path. P5 requires a controlled, narrowly scoped async
instrumentation variant with fixed request size and independently swept buffer
depth.
