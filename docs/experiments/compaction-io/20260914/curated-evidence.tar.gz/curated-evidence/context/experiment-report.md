# Compaction io_uring Depth Experiment

## Scope

This run evaluates the internal `--experimental_compaction_io_depth` path with
a fixed 1 MiB request span, direct reads, one compaction thread, and a restored
81-L0 seed. It does not change public RocksDB API or persistent formats.

The release `db_bench` was rebuilt after installing `liburing-dev` and
`liburing2`. The binary links `liburing.so.2`; an exact 256-entry ring probe
using `IORING_SETUP_SINGLE_ISSUER | IORING_SETUP_DEFER_TASKRUN` returned `rc=0`.

## Method

- 24 runs: depth 0, 1, 2, 4, 8, 16, 32, and 64; three repetitions each.
- Every run used a fresh copy of the same generated source.
- Every run completed `compact0` from 81 L0 files to L1 with exit status 0.
- Results: `results/experiment-data/uring-depth-summary.csv`.
- Per-run CLI, iostat, status, and OPTIONS artifacts: `results/experiment-data/uring_d*_r*/`.
- Seed provenance: `results/experiment-data/uring-seed-rebuild/`.
- Depth 0 does not instantiate custom experiment instrumentation; its CSV
  metric fields are explicit zero sentinels for schema consistency.

## Aggregate Results

| Depth | Wall mean (s) | Compaction mean (s) | Read bytes | Stall mean | Overlap mean (us) | Exposed mean (us) |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 0 | 105.56 | 101.00 | n/a | 0 | n/a | n/a |
| 1 | 114.84 | 108.87 | 21.19 GB | 0 | 0 | 0.00 |
| 2 | 93.67 | 89.37 | 21.24 GB | 643 | 217,911 | 44.16 |
| 4 | 138.31 | 133.97 | 37.22 GB | 171 | 485,666 | 71.50 |
| 8 | 219.80 | 216.63 | 40.18 GB | 84 | 1,073,340 | 165.90 |
| 16 | 223.39 | 219.53 | 41.60 GB | 43 | 1,499,430 | 239.34 |
| 32 | 227.61 | 224.20 | 42.30 GB | 24 | 2,176,510 | 640.24 |
| 64 | 177.56 | 174.07 | 42.77 GB | 9 | 3,412,421 | 1,750.44 |

All positive-depth runs ended with `outstanding_async_reads=0`, consumed bytes
`21127350524`, and matching L1/L2 output shape. Compaction logs reported zero
checksum mismatches. Depth 0 is the synchronous control and has no outstanding
async reads by construction.

## Q1: Does Compaction Use Real Async I/O?

Yes. Depth 2 through 64 issued asynchronous reads with 1 MiB request spans,
produced successful completions, and recorded nonzero overlap. Depth 1 is
functionally enabled but has one buffer and recorded no overlap.

## Q2: Does Larger Depth Reduce Exposed Stall?

It reduces stall count after depth 2: 643 at depth 2, 171 at depth 4, and 9 at
depth 64. Exposed time rises in this storage-contended sweep, so the data does
not support a clean latency-hiding curve.

## Q3: Is The Speedup Pure Latency Hiding?

No proof. Depth 2 is fastest in this corrected sweep, but depths 4--64 reread
substantially more data than the 21.13 GB consumed. The result combines
queueing/overlap effects with request scheduling, read amplification, and
storage contention. Device utilization and output writes remain confounders.

## Q4: Which Depth Is Best?

Depth 2 is the best observed throughput point: 93.67 s wall mean and 89.37 s
compaction mean. Depth 64 minimizes stall count but is slower and reads about
twice consumed bytes. Do not select depth 64 solely from stall count.

## Q5: Is The Pipeline Correct And Reproducible?

Within this scenario, yes. All 24 runs passed, selected the expected 81 L0
files, produced the same output-level shape, consumed identical bytes, ended
with no outstanding requests for positive depths, and reported no checksum
mismatch. Invalid depth 3 was rejected with exit status 1; evidence is
`results/experiment-data/edge-invalid-depth.log`.

This is not a full RocksDB test-suite result. The previously observed
`PrefetchTest.Basic/0` failure and strict release warning in
`util/compression.cc:1564` remain separate known issues. The release benchmark
used `DISABLE_WARNING_AS_ERROR=1` without changing that source file.

## Q6: What Machine Is Required?

- Linux kernel 6.1+ for the exact `DEFER_TASKRUN` setup flags, absent vendor
  backports.
- liburing headers and library at build time; Make must compile `<liburing.h>`
  with `-luring`, or CMake must find `uring` with `WITH_LIBURING=ON`.
- Runtime permission for `io_uring_setup` and `io_uring_enter`; no blocking
  seccomp policy, disabled io_uring sysctl, or exhausted file-descriptor
  limits.
- Direct-I/O alignment when direct reads are enabled.
- NVMe is not required for functionality. Local SSD/NVMe is preferred for
  meaningful storage-latency measurements; never write fio data to raw devices.

The current host is Ubuntu 24.04, kernel 6.4.6, with liburing 2.5 and a
successful runtime ring probe.

## Verification

- Release/static `db_bench` build: PASS with `DISABLE_WARNING_AS_ERROR=1`.
- `FilePrefetchBufferTest.*` and `CompactionIOExperimentTest.*`: 10/10 PASS
  under an io_uring-enabled debug build.
- `git diff --check`: PASS.
- `make check-sources`: PASS.
- Corrected sweep: 24/24 runs exit 0; every positive-depth JSON record reports
  `request_span_bytes=1048576` and `outstanding_async_reads=0`.
- clangd diagnostics are not clean because this checkout has no project
  compile-command/include configuration; reported errors are unresolved
  include paths, not compiler failures.

## Conclusion

The implementation reaches the real POSIX io_uring path, keeps ordinary
compaction async requests at 1 MiB, and safely completes the compaction
pipeline. Depth 2 is the practical candidate in this corrected sweep, but the
experiment does not establish pure latency hiding because larger depths
increase read amplification and exposed time increases under this run
envelope. Further causal claims require a controlled device envelope and
repeated async/off comparisons with storage telemetry.
