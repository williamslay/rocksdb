# Isolated compaction input/output experiment

Batch: `batch-20260831T084602Z`
Generated only from raw accepted run artifacts.

## Decision
Classification: **inconclusive**
Knee: **8**

Accepted runs: 15
Rejected runs: 0
Counts by depth: 2=3, 4=3, 8=3, 16=3, 32=3
Best depth by mean E_io: 8
T_exposed_io reduction depth 2 to best: 53.33%
E_io reduction depth 2 to best: 63.88%
Wall-time reduction depth 2 to best: -27.68%
wall_insensitive=False
work_comparable=True
read_amp_stable=False
device_not_saturated=False
read_below_envelope=False (no existing envelope artifact)

## Raw evidence
- `results/isolated-experiment/runs/batch-20260831T084602Z-d02-r1/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d02-r1/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d02-r1/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d02-r1/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d02-r2/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d02-r2/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d02-r2/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d02-r2/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d02-r3/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d02-r3/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d02-r3/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d02-r3/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d04-r1/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d04-r1/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d04-r1/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d04-r1/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d04-r2/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d04-r2/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d04-r2/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d04-r2/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d04-r3/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d04-r3/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d04-r3/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d04-r3/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d08-r1/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d08-r1/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d08-r1/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d08-r1/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d08-r2/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d08-r2/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d08-r2/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d08-r2/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d08-r3/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d08-r3/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d08-r3/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d08-r3/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d16-r1/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d16-r1/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d16-r1/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d16-r1/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d16-r2/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d16-r2/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d16-r2/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d16-r2/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d16-r3/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d16-r3/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d16-r3/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d16-r3/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d32-r1/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d32-r1/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d32-r1/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d32-r1/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d32-r2/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d32-r2/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d32-r2/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d32-r2/iostat.raw`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d32-r3/status.txt`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d32-r3/interval.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d32-r3/metrics.json`
- `results/isolated-experiment/runs/batch-20260831T084602Z-d32-r3/iostat.raw`

## Definitions
- `E_io = T_exposed_io / T_compaction` per run.
- Arithmetic means and sample standard deviations use independent completed runs; `N` is run count.
- Read amplification is `physical_read_bytes / logical_consumed_bytes`; prefetched bytes remain separate evidence.
- Positive classification requires predeclared comparability, stability, device, wall-time, and read-envelope gates.
- No CMM-H, Cylon, depth64, or expanded depth/request-size search was performed.
